# Lab 1

## Task 1

Plot a graph ranging from -pi to pi with color green and dashed line for the following function:

$$f(x) = \cos(x) + 2$$

## Task 2

Use riemann integral using mid points to calculate

$$f(x) = \cos(x)$$

from -pi to pi;

Plot the bar graph and actual graph.

Compare with actual value.

use 10 intervals and then 100 intervals.

Output should be something like

riemann sum using 10 intervals = someVal1
Error = someVal

riemann sum using 100 intervals = someVal1
Error = someVal
